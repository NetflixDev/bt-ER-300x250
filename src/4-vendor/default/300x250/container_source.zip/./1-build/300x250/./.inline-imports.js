import { InlineSrc } from 'ad-assets'
window.InlineSrc = InlineSrc

